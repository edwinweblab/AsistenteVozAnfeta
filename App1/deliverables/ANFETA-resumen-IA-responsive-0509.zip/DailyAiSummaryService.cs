using Anfeta.UI.Models.DailyAi;
using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Anfeta.UI.Services.Search;

public sealed class DailyAiSummaryService
{
    public const string Model = "gpt-4.1-mini-2025-04-14";
    private static readonly HttpClient Client = new(new HttpClientHandler { AllowAutoRedirect = false })
        { Timeout = TimeSpan.FromSeconds(35), MaxResponseContentBufferSize = 262144 };
    private static readonly SemaphoreSlim Gate = new(1, 1);
    private static string? _lastInput;
    private static DailyAiNarrative? _lastSummary;
    private static DateTimeOffset _lastRequest;

    public static string BuildPayload(DailyAiSnapshot snapshot) => JsonSerializer.Serialize(new
    {
        snapshot.Date,
        snapshot.Metrics,
        Projects = snapshot.Projects.Select(project => new
        {
            project.ProjectName, project.Domain, project.Area, project.ResponsiblePeople,
            project.ActivitiesToday, project.CompletedToday, project.PendingToday,
            project.ProgressTodayPct, project.ProgressTotalPct, project.IsCritical,
            project.IsLagging, project.IsInReview, project.IsSuspended, project.IsUnassigned,
            project.CriticalReasons
        }),
        snapshot.People,
        snapshot.Areas,
        snapshot.DataNote
    });

    public async Task<DailyAiNarrative> GenerateAsync(string key, DailyAiSnapshot snapshot, CancellationToken cancellationToken)
    {
        var input = BuildPayload(snapshot);
        await Gate.WaitAsync(cancellationToken);
        try
        {
            var cacheKey = snapshot.Date.ToString("yyyy-MM-dd") + snapshot.Fingerprint;
            if (_lastInput == cacheKey && _lastSummary != null) return _lastSummary;
            if (DateTimeOffset.UtcNow - _lastRequest < TimeSpan.FromSeconds(30))
                throw new InvalidOperationException("Espera 30 segundos antes de otra consulta.");
            if (string.IsNullOrWhiteSpace(key)) throw new InvalidOperationException("Falta la clave de OpenAI.");
            var stringArray = new { type = "array", items = new { type = "string" } };
            var schema = new
            {
                type = "object",
                properties = new
                {
                    summary = new { type = "string" }, attentionItems = stringArray, positiveSignals = stringArray,
                    priorities = stringArray, workloadObservations = stringArray
                },
                required = new[] { "summary", "attentionItems", "positiveSignals", "priorities", "workloadObservations" },
                additionalProperties = false
            };
            var payload = new
            {
                model = Model, store = false, max_output_tokens = 900,
                instructions = "Analiza únicamente el JSON proporcionado y responde en español. ANFETA ya calculó todas las métricas: no las recalcules ni inventes proyectos, personas, porcentajes, fechas, causas o actividades. Explica qué requiere atención usando exclusivamente CriticalReasons. No clasifiques suspendidos como críticos solo por falta de avance. Si no hay evidencia suficiente, indícalo. Prioriza recomendaciones operativas prudentes, no órdenes automáticas.",
                input,
                text = new { format = new { type = "json_schema", name = "anfeta_daily_narrative", strict = true, schema } }
            };
            using var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/responses");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", key.Trim());
            request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            _lastRequest = DateTimeOffset.UtcNow;
            using var response = await Client.SendAsync(request, cancellationToken);
            if (!response.IsSuccessStatusCode)
                throw new InvalidOperationException((int)response.StatusCode switch
                {
                    401 => "La clave de OpenAI no es válida. Revisa la configuración.",
                    403 or 404 => "La cuenta no tiene acceso al modelo configurado.",
                    429 => "OpenAI indica límite de consumo o solicitudes. Revisa el saldo y los límites de tu cuenta.",
                    _ => "OpenAI no respondió correctamente. El resumen local sigue disponible."
                });
            var result = ParseResponse(await response.Content.ReadAsStringAsync(cancellationToken));
            _lastInput = cacheKey;
            _lastSummary = result;
            return result;
        }
        finally { Gate.Release(); }
    }

    public static DailyAiNarrative ParseResponse(string json)
    {
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;
        if (!root.TryGetProperty("status", out var status) || status.GetString() != "completed")
            throw new InvalidOperationException("El resumen quedó incompleto. No se mostrará como resultado válido.");
        var text = string.Concat(root.GetProperty("output").EnumerateArray()
            .Where(x => x.TryGetProperty("type", out var type) && type.GetString() == "message")
            .SelectMany(x => x.GetProperty("content").EnumerateArray())
            .Where(x => x.GetProperty("type").GetString() == "output_text")
            .Select(x => x.GetProperty("text").GetString()));
        if (text.Length == 0 || text.Length > 16000) throw new InvalidOperationException("OpenAI no devolvió un resumen válido.");
        var result = JsonSerializer.Deserialize<DailyAiNarrative>(text, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        if (result == null || string.IsNullOrWhiteSpace(result.Summary))
            throw new InvalidOperationException("La respuesta de IA no contiene todos los campos.");
        return result;
    }
}
