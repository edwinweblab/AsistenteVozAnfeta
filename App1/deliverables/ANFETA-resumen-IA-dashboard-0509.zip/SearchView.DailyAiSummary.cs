using Anfeta.UI.Models.DailyAi;
using Anfeta.UI.Services.Notion;
using Anfeta.UI.Services.Reports;
using Anfeta.UI.Services.Search;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Windows.Security.Credentials;
using Windows.System;

namespace Anfeta.UI.Views;

public sealed partial class SearchView
{
    private bool _dailySummaryOpen;
    private const string SummaryCredential = "ANFETA.OpenAI.Summary";
    private static SolidColorBrush DailyBrush(byte r, byte g, byte b) => new(ColorHelper.FromArgb(255, r, g, b));
    private static readonly SolidColorBrush DailyPanelBrush = DailyBrush(12, 22, 31);
    private static readonly SolidColorBrush DailyCardBrush = DailyBrush(17, 30, 42);
    private static readonly SolidColorBrush DailyBorderBrush = DailyBrush(38, 59, 75);
    private static readonly SolidColorBrush DailyMutedBrush = DailyBrush(157, 177, 194);

    private async void DailyAiSummary_Click(object sender, RoutedEventArgs e)
    {
        if (_dailySummaryOpen) return;
        _dailySummaryOpen = true;
        using var cancellation = new CancellationTokenSource();
        try
        {
            var token = GetSavedNotionToken();
            if (string.IsNullOrWhiteSpace(token)) throw new InvalidOperationException("Configura primero el token de Notion.");
            StatusText.Text = "Estado: Preparando Resumen IA desde Avance Diario…";
            var progress = await new NotionDailyProgressService().BuildAsync(_notionCalendarService, token, DateTime.Today,
                forceRefresh: false, requireFreshDay: false, cancellationToken: cancellation.Token);
            var snapshot = new DailyAiSnapshotBuilder().Build(progress);
            var paths = await new DailyReportDatasetService().ExportAsync(snapshot, cancellation.Token);
            var m = snapshot.Metrics;

            var dashboard = new StackPanel { Spacing = 14 };
            dashboard.Children.Add(CreateDailyHeader(snapshot));
            dashboard.Children.Add(CreateDailyKpis(m));
            dashboard.Children.Add(CreateCriticalProjectsCard(snapshot));
            dashboard.Children.Add(CreatePeopleCard(snapshot));

            var dataPanel = new StackPanel { Spacing = 8 };
            dataPanel.Children.Add(DailyText("Los cálculos se guardaron localmente. OpenAI recibe el snapshot operativo, pero no cuerpos de Notion, comentarios ni Dropbox.", 13, DailyMutedBrush));
            var openFolder = new Button { Content = "📂 Abrir datos JSON/CSV", HorizontalAlignment = HorizontalAlignment.Left };
            openFolder.Click += async (_, _) => await Launcher.LaunchFolderPathAsync(paths.OutputDirectory);
            dataPanel.Children.Add(openFolder);
            dashboard.Children.Add(CreateDailyCard("DATOS DEL REPORTE", "Salida auditable", DailyBrush(29, 180, 242), dataPanel));

            var miaoService = new MiaoVisionInstallerService();
            var miaoStatus = await miaoService.GetStatusAsync(cancellation.Token);
            var miaoPanel = new StackPanel { Spacing = 9 };
            var miaoInfo = new InfoBar
            {
                IsOpen = true,
                IsClosable = false,
                Severity = miaoStatus.IsInstalled ? InfoBarSeverity.Success : InfoBarSeverity.Informational,
                Title = miaoStatus.IsInstalled ? "Motor listo" : "Instalación requerida",
                Message = miaoStatus.Message
            };
            miaoPanel.Children.Add(miaoInfo);
            if (!miaoStatus.IsInstalled)
                AddMiaoInstallerControls(miaoPanel, miaoService, miaoInfo, cancellation.Token);
            else
                miaoPanel.Children.Add(DailyText("La instalación fue validada con el checksum oficial. El siguiente bloque habilitará la generación de HTML y PDF.", 13, DailyMutedBrush));
            dashboard.Children.Add(CreateDailyCard("MIAO VISION", "Motor local de HTML y PDF", DailyBrush(42, 207, 142), miaoPanel));

            dashboard.Children.Add(CreateAiCard(snapshot, cancellation.Token));
            var contentBorder = new Border
            {
                Background = DailyPanelBrush,
                BorderBrush = DailyBorderBrush,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(16),
                Width = Math.Max(560, Math.Min(940, XamlRoot.Size.Width - 140)),
                Child = dashboard
            };
            var dialog = new ContentDialog
            {
                XamlRoot = XamlRoot,
                Title = "Resumen del día · IA",
                CloseButtonText = "Cerrar",
                Content = new ScrollViewer
                {
                    Content = contentBorder,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                    MaxHeight = Math.Max(320, XamlRoot.Size.Height - 190)
                }
            };
            dialog.Closing += (_, _) => cancellation.Cancel();
            StatusText.Text = $"Estado: Resumen diario listo · {m.TotalProjects} proyectos · {m.TotalActivities} actividades";
            await dialog.ShowAsync();
        }
        catch (Exception ex) { StatusText.Text = "No se pudo abrir el resumen: " + ex.Message; }
        finally { cancellation.Cancel(); _dailySummaryOpen = false; }
    }

    private static UIElement CreateDailyHeader(DailyAiSnapshot snapshot)
    {
        var panel = new StackPanel { Spacing = 3 };
        panel.Children.Add(DailyText("ANFETA · RESUMEN OPERATIVO", 12, DailyBrush(72, 190, 245), true));
        panel.Children.Add(DailyText(snapshot.Date.ToString("dddd, dd 'de' MMMM 'de' yyyy"), 23, DailyBrush(241, 247, 252), true));
        panel.Children.Add(DailyText("Métricas reales calculadas por Avance Diario", 13, DailyMutedBrush));
        return panel;
    }

    private static UIElement CreateDailyKpis(DailyAiMetrics m)
    {
        var values = new (string Label, int Value, SolidColorBrush Accent)[]
        {
            ("PROYECTOS", m.TotalProjects, DailyBrush(29,180,242)), ("ACTIVIDADES", m.TotalActivities, DailyBrush(90,165,255)),
            ("REZAGADAS", m.LaggingActivities, DailyBrush(255,88,96)), ("PENDIENTES", m.PendingToday, DailyBrush(245,185,55)),
            ("TERMINADAS HOY", m.CompletedToday, DailyBrush(42,207,142)), ("EN REVISIÓN", m.ProjectsInReview, DailyBrush(180,115,255)),
            ("SIN RESPONSABLE", m.UnassignedActivities, DailyBrush(255,145,70)), ("SIN CHECKLIST", m.MissingChecklistActivities, DailyBrush(135,151,165))
        };
        var grid = new Grid { ColumnSpacing = 8, RowSpacing = 8 };
        for (var i = 0; i < 4; i++) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        for (var i = 0; i < values.Length; i++)
        {
            var stack = new StackPanel { Spacing = 2 };
            stack.Children.Add(DailyText(values[i].Value.ToString(), 22, values[i].Accent, true));
            stack.Children.Add(DailyText(values[i].Label, 10, DailyMutedBrush, true));
            var border = new Border { Background = DailyCardBrush, BorderBrush = DailyBorderBrush, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(7), Padding = new Thickness(12, 9, 12, 9), Child = stack };
            Grid.SetColumn(border, i % 4); Grid.SetRow(border, i / 4); grid.Children.Add(border);
        }
        return grid;
    }

    private static UIElement CreateCriticalProjectsCard(DailyAiSnapshot snapshot)
    {
        var panel = new StackPanel { Spacing = 6 };
        var rows = snapshot.Projects.Where(x => x.IsCritical).Take(10).ToList();
        if (rows.Count == 0) panel.Children.Add(DailyText("No hay proyectos críticos con las reglas actuales.", 13, DailyMutedBrush));
        foreach (var project in rows)
        {
            var row = new Grid { ColumnSpacing = 12 };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var name = DailyText(project.ProjectName, 13, DailyBrush(241, 247, 252), true);
            var reason = DailyText(string.Join("  ·  ", project.CriticalReasons), 12, DailyBrush(255, 159, 95));
            Grid.SetColumn(name, 0); Grid.SetColumn(reason, 1); row.Children.Add(name); row.Children.Add(reason);
            panel.Children.Add(new Border { Background = DailyBrush(20, 32, 43), CornerRadius = new CornerRadius(5),
                BorderBrush = DailyBrush(81, 48, 46), BorderThickness = new Thickness(2, 0, 0, 0), Padding = new Thickness(9, 7, 9, 7), Child = row });
        }
        return CreateDailyCard("PROYECTOS QUE REQUIEREN ATENCIÓN", $"{rows.Count} mostrados", DailyBrush(255, 88, 96), panel);
    }

    private static UIElement CreatePeopleCard(DailyAiSnapshot snapshot)
    {
        var panel = new StackPanel { Spacing = 5 };
        panel.Children.Add(CreatePeopleRow("RESPONSABLE", "ACT.", "PEND.", "REZ.", true));
        foreach (var person in snapshot.People.Take(12))
            panel.Children.Add(CreatePeopleRow(person.Name, person.ActivitiesToday.ToString(), person.PendingToday.ToString(), person.LaggingActivities.ToString(), false));
        return CreateDailyCard("CARGA POR PERSONA", "Actividad operativa del día", DailyBrush(29, 180, 242), panel);
    }

    private static UIElement CreatePeopleRow(string name, string activities, string pending, string lagging, bool header)
    {
        var grid = new Grid { ColumnSpacing = 8, Margin = new Thickness(6, 4, 6, 4) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
        var values = new[] { name, activities, pending, lagging };
        for (var i = 0; i < values.Length; i++) { var text = DailyText(values[i], header ? 10 : 12, header ? DailyMutedBrush : DailyBrush(224, 234, 242), header); Grid.SetColumn(text, i); grid.Children.Add(text); }
        return grid;
    }

    private void AddMiaoInstallerControls(StackPanel panel, MiaoVisionInstallerService service, InfoBar info, CancellationToken cancellationToken)
    {
        var consent = new CheckBox { Content = new TextBlock { Text = "Autorizo descargar Miao Vision 0.6.2 para Windows (aprox. 91 MB) desde GitHub.", TextWrapping = TextWrapping.Wrap } };
        var install = new Button { Content = "Instalar motor de reportes", IsEnabled = false, HorizontalAlignment = HorizontalAlignment.Left };
        consent.Checked += (_, _) => install.IsEnabled = true;
        consent.Unchecked += (_, _) => install.IsEnabled = false;
        install.Click += async (_, _) =>
        {
            install.IsEnabled = false; consent.IsEnabled = false;
            var finished = false;
            try
            {
                var downloadProgress = new Progress<double>(value =>
                {
                    if (finished) return;
                    install.Content = $"Descargando y verificando… {value:0}%";
                    info.Title = "Instalando motor"; info.Message = $"Descarga oficial en curso · {value:0}%";
                });
                var installed = await service.InstallAsync(downloadProgress, cancellationToken);
                finished = true;
                info.Severity = InfoBarSeverity.Success; info.Title = "Instalación completada";
                info.Message = installed.Message + " Ya puede cerrarse este resumen y volver a abrirse.";
                install.Content = "Motor instalado ✓"; consent.Visibility = Visibility.Collapsed;
                StatusText.Text = "Estado: Miao Vision instalado y verificado correctamente ✅";
            }
            catch (OperationCanceledException) { finished = true; info.Severity = InfoBarSeverity.Warning; info.Title = "Instalación cancelada"; info.Message = "No se realizaron cambios incompletos."; install.Content = "Reintentar instalación"; }
            catch (Exception ex) { finished = true; info.Severity = InfoBarSeverity.Error; info.Title = "No se pudo instalar"; info.Message = ex.Message; install.Content = "Reintentar instalación"; }
            finally { consent.IsEnabled = true; if (consent.Visibility == Visibility.Visible) install.IsEnabled = consent.IsChecked == true; }
        };
        panel.Children.Add(consent); panel.Children.Add(install);
    }

    private UIElement CreateAiCard(DailyAiSnapshot snapshot, CancellationToken cancellationToken)
    {
        var panel = new StackPanel { Spacing = 9 };
        var keyBox = new PasswordBox { Header = "Clave de OpenAI", PlaceholderText = "Solo para configurarla o cambiarla" };
        var remember = new CheckBox { Content = "Guardar en Credenciales de Windows" };
        var consent = new CheckBox { Content = new TextBlock { Text = "Autorizo enviar el snapshot operativo a OpenAI y el consumo de mi cuenta API.", TextWrapping = TextWrapping.Wrap } };
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        var generate = new Button { Content = "✦ Generar interpretación", IsEnabled = false };
        var forget = new Button { Content = "Borrar clave" };
        actions.Children.Add(generate); actions.Children.Add(forget);
        var output = new StackPanel { Spacing = 8 };
        output.Children.Add(DailyText("El resumen operativo ya está disponible sin IA.", 13, DailyMutedBrush));
        var vault = new PasswordVault();
        try { vault.Retrieve(SummaryCredential, "user"); output.Children.Clear(); output.Children.Add(DailyText("Hay una clave guardada. No se enviará nada hasta que lo autorices.", 13, DailyMutedBrush)); } catch { }
        consent.Checked += (_, _) => generate.IsEnabled = snapshot.Activities.Count > 0;
        consent.Unchecked += (_, _) => generate.IsEnabled = false;
        forget.Click += (_, _) => { try { vault.Remove(vault.Retrieve(SummaryCredential, "user")); SetAiMessage(output, "Clave guardada eliminada.", false); } catch { SetAiMessage(output, "No hay una clave guardada.", false); } keyBox.Password = ""; };
        generate.Click += async (_, _) =>
        {
            generate.IsEnabled = false; consent.IsEnabled = false;
            try
            {
                var key = keyBox.Password.Trim();
                if (key.Length == 0) { var credential = vault.Retrieve(SummaryCredential, "user"); credential.RetrievePassword(); key = credential.Password; }
                if (remember.IsChecked == true) vault.Add(new PasswordCredential(SummaryCredential, "user", key));
                keyBox.Password = ""; SetAiMessage(output, "Generando interpretación…", false);
                RenderNarrative(output, await new DailyAiSummaryService().GenerateAsync(key, snapshot, cancellationToken));
            }
            catch (OperationCanceledException) { SetAiMessage(output, "Solicitud cancelada o tiempo agotado.", true); }
            catch (Exception ex) { SetAiMessage(output, ex is InvalidOperationException ? ex.Message : "No se obtuvo una interpretación válida; los datos locales siguen disponibles.", true); }
            finally { consent.IsEnabled = true; generate.IsEnabled = consent.IsChecked == true && snapshot.Activities.Count > 0; }
        };
        panel.Children.Add(keyBox); panel.Children.Add(remember); panel.Children.Add(consent); panel.Children.Add(actions); panel.Children.Add(output);
        return CreateDailyCard("INTERPRETACIÓN IA", "Opcional · no modifica Notion", DailyBrush(180, 115, 255), panel);
    }

    private static void RenderNarrative(StackPanel output, DailyAiNarrative value)
    {
        output.Children.Clear();
        output.Children.Add(DailyText(value.Summary, 14, DailyBrush(241, 247, 252), true));
        AddNarrativeSection(output, "ATENCIÓN", value.AttentionItems, DailyBrush(255, 112, 112));
        AddNarrativeSection(output, "SEÑALES POSITIVAS", value.PositiveSignals, DailyBrush(42, 207, 142));
        AddNarrativeSection(output, "PRIORIDADES", value.Priorities, DailyBrush(245, 185, 55));
        AddNarrativeSection(output, "CARGA", value.WorkloadObservations, DailyBrush(29, 180, 242));
    }

    private static void AddNarrativeSection(StackPanel output, string title, IReadOnlyList<string> rows, SolidColorBrush accent)
    {
        if (rows.Count == 0) return;
        var stack = new StackPanel { Spacing = 3 };
        stack.Children.Add(DailyText(title, 10, accent, true));
        foreach (var row in rows) stack.Children.Add(DailyText("• " + row, 12, DailyBrush(220, 231, 239)));
        output.Children.Add(new Border { Background = DailyBrush(15, 27, 37), CornerRadius = new CornerRadius(5), Padding = new Thickness(10, 8, 10, 8), Child = stack });
    }

    private static void SetAiMessage(StackPanel output, string message, bool error)
    {
        output.Children.Clear(); output.Children.Add(DailyText(message, 13, error ? DailyBrush(255, 112, 112) : DailyMutedBrush));
    }

    private static Border CreateDailyCard(string title, string subtitle, SolidColorBrush accent, UIElement content)
    {
        var header = new Grid { ColumnSpacing = 8 };
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(4) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var stripe = new Border { Background = accent, CornerRadius = new CornerRadius(2) };
        var labels = new StackPanel { Spacing = 1 };
        labels.Children.Add(DailyText(title, 12, DailyBrush(235, 243, 249), true));
        labels.Children.Add(DailyText(subtitle, 11, DailyMutedBrush));
        Grid.SetColumn(stripe, 0); Grid.SetColumn(labels, 1); header.Children.Add(stripe); header.Children.Add(labels);
        var panel = new StackPanel { Spacing = 10 }; panel.Children.Add(header); panel.Children.Add(content);
        return new Border { Background = DailyCardBrush, BorderBrush = DailyBorderBrush, BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(8), Padding = new Thickness(13), Child = panel };
    }

    private static TextBlock DailyText(string text, double size, SolidColorBrush brush, bool bold = false) => new()
    {
        Text = text, FontSize = size, Foreground = brush, TextWrapping = TextWrapping.Wrap,
        FontWeight = bold ? Microsoft.UI.Text.FontWeights.SemiBold : Microsoft.UI.Text.FontWeights.Normal
    };
}
