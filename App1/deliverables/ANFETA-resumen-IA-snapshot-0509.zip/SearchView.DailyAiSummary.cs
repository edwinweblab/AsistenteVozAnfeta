using Anfeta.UI.Models.DailyAi;
using Anfeta.UI.Services.Notion;
using Anfeta.UI.Services.Reports;
using Anfeta.UI.Services.Search;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using System;
using System.Linq;
using System.Text;
using System.Threading;
using Windows.Security.Credentials;
using Windows.System;

namespace Anfeta.UI.Views;

public sealed partial class SearchView
{
    private bool _dailySummaryOpen;
    private const string SummaryCredential = "ANFETA.OpenAI.Summary";

    private async void DailyAiSummary_Click(object sender, RoutedEventArgs e)
    {
        if (_dailySummaryOpen) return;
        _dailySummaryOpen = true;
        using var cancellation = new CancellationTokenSource();
        try
        {
            var token = GetSavedNotionToken();
            if (string.IsNullOrWhiteSpace(token)) throw new InvalidOperationException("Configura primero el token de Notion.");
            StatusText.Text = "Estado: Preparando Resumen IA desde Avance Diario…";
            var progress = await new NotionDailyProgressService().BuildAsync(_notionCalendarService, token, DateTime.Today,
                forceRefresh: false, requireFreshDay: false, cancellationToken: cancellation.Token);
            var snapshot = new DailyAiSnapshotBuilder().Build(progress);
            var paths = await new DailyReportDatasetService().ExportAsync(snapshot, cancellation.Token);

            var panel = new StackPanel { Spacing = 10 };
            TextBlock Label(string text) => new() { Text = text, TextWrapping = TextWrapping.Wrap };
            var m = snapshot.Metrics;
            panel.Children.Add(Label($"✦ RESUMEN OPERATIVO · {snapshot.Date:dd/MM/yyyy}\n" +
                $"{m.TotalProjects} proyectos · {m.TotalActivities} actividades · {m.LaggingActivities} rezagadas\n" +
                $"Pendientes: {m.PendingToday} · Terminadas hoy: {m.CompletedToday} · En revisión: {m.ProjectsInReview}\n" +
                $"Suspendidos: {m.SuspendedProjects} · Sin responsable: {m.UnassignedActivities} · Sin checklist: {m.MissingChecklistActivities}"));
            var critical = snapshot.Projects.Where(x => x.IsCritical).Take(8).ToList();
            panel.Children.Add(Label(critical.Count == 0 ? "⚠ Atención\nSin proyectos críticos con las reglas actuales." :
                "⚠ Atención\n" + string.Join("\n", critical.Select(x => $"• {x.ProjectName}: {string.Join("; ", x.CriticalReasons)}"))));
            panel.Children.Add(Label("📊 Carga\n" + string.Join("\n", snapshot.People.Take(10).Select(x =>
                $"• {x.Name}: {x.ActivitiesToday} actividades · {x.PendingToday} pendientes · {x.LaggingActivities} rezagadas"))));
            panel.Children.Add(Label("Datos exportados localmente. La IA recibe métricas, proyectos, responsables y razones calculadas; no recibe cuerpos de Notion, comentarios ni Dropbox."));

            var openFolder = new Button { Content = "Abrir datos JSON/CSV", HorizontalAlignment = HorizontalAlignment.Stretch };
            openFolder.Click += async (_, _) => await Launcher.LaunchFolderPathAsync(paths.OutputDirectory);
            panel.Children.Add(openFolder);

            var keyBox = new PasswordBox { Header = "Clave de OpenAI (solo para configurarla o cambiarla)", PlaceholderText = "No pegues la clave en el chat" };
            var remember = new CheckBox { Content = "Guardar mi clave en Credenciales de Windows", IsChecked = false };
            var forget = new Button { Content = "Borrar clave guardada" };
            var consent = new CheckBox { Content = new TextBlock { Text = "Autorizo enviar el snapshot operativo a OpenAI y el consumo de mi cuenta API.", TextWrapping = TextWrapping.Wrap } };
            var generate = new Button { Content = "Generar interpretación IA", IsEnabled = false, HorizontalAlignment = HorizontalAlignment.Stretch };
            var result = Label("El resumen operativo local ya está disponible sin API. Miao Vision no está instalado; HTML/PDF permanece deshabilitado.");
            var vault = new PasswordVault();
            try { vault.Retrieve(SummaryCredential, "user"); result.Text = "Resumen local listo. Hay una clave guardada; no se enviará nada hasta autorizar y pulsar Generar."; } catch { }
            consent.Checked += (_, _) => generate.IsEnabled = snapshot.Activities.Count > 0;
            consent.Unchecked += (_, _) => generate.IsEnabled = false;
            forget.Click += (_, _) => { try { vault.Remove(vault.Retrieve(SummaryCredential, "user")); result.Text = "Clave guardada eliminada."; } catch { result.Text = "No hay una clave guardada."; } keyBox.Password = ""; };
            generate.Click += async (_, _) =>
            {
                generate.IsEnabled = false; consent.IsEnabled = false;
                try
                {
                    var key = keyBox.Password.Trim();
                    if (key.Length == 0) { var credential = vault.Retrieve(SummaryCredential, "user"); credential.RetrievePassword(); key = credential.Password; }
                    if (remember.IsChecked == true) vault.Add(new PasswordCredential(SummaryCredential, "user", key));
                    keyBox.Password = ""; result.Text = "Generando interpretación…";
                    result.Text = FormatNarrative(await new DailyAiSummaryService().GenerateAsync(key, snapshot, cancellation.Token));
                }
                catch (OperationCanceledException) { result.Text = "Solicitud cancelada o tiempo de espera agotado."; }
                catch (Exception ex) { result.Text = ex is InvalidOperationException ? ex.Message : "No se pudo obtener una interpretación válida; los datos locales siguen disponibles."; }
                finally { consent.IsEnabled = true; generate.IsEnabled = consent.IsChecked == true && snapshot.Activities.Count > 0; }
            };
            panel.Children.Add(keyBox); panel.Children.Add(remember); panel.Children.Add(forget);
            panel.Children.Add(consent); panel.Children.Add(generate); panel.Children.Add(result);
            var dialog = new ContentDialog { XamlRoot = XamlRoot, Title = "Resumen del día · IA", CloseButtonText = "Cerrar",
                Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, MaxHeight = Math.Max(120, XamlRoot.Size.Height - 220) } };
            dialog.Closing += (_, _) => cancellation.Cancel();
            StatusText.Text = $"Estado: Resumen diario listo · {m.TotalProjects} proyectos · {m.TotalActivities} actividades";
            await dialog.ShowAsync();
        }
        catch (Exception ex) { StatusText.Text = "No se pudo abrir el resumen: " + ex.Message; }
        finally { cancellation.Cancel(); _dailySummaryOpen = false; }
    }

    private static string FormatNarrative(DailyAiNarrative value)
    {
        var text = new StringBuilder("✦ INTERPRETACIÓN IA\n").AppendLine(value.Summary);
        void Add(string title, System.Collections.Generic.IReadOnlyList<string> rows)
        { if (rows.Count > 0) text.Append('\n').AppendLine(title).AppendLine(string.Join("\n", rows.Select(x => "• " + x))); }
        Add("⚠ Atención", value.AttentionItems); Add("✓ Señales positivas", value.PositiveSignals);
        Add("🎯 Prioridades", value.Priorities); Add("📊 Carga", value.WorkloadObservations);
        return text.ToString().Trim();
    }
}
